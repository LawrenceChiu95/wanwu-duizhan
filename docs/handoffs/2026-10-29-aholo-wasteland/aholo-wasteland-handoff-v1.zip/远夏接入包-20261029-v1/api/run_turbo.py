"""Local Aholo photo -> styled image -> GLB test; standard library only."""
import argparse
import getpass
import hashlib
import json
import os
from pathlib import Path
import struct
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parent
BASE = 'https://api.aholo.ai/global'


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)


def request(url, headers=None, body=None, method=None):
    req = urllib.request.Request(url, data=body, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'HTTP {error.code}; request failed. Check account permissions and console task history.') from None


def unwrap(reply):
    if str(reply.get('c')) != '0':
        raise RuntimeError(f'API business error code: {reply.get("c")}. Check console.')
    return reply['d']


def multipart(fields, chunk):
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in fields.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="photo.jpg"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode())
    return b''.join(parts) + chunk + f'\r\n--{boundary}--\r\n'.encode(), boundary


def upload(photo, key):
    token = request(BASE + '/asset/v1/token', {'Authorization': key})
    domain = token['globalDomain'].rstrip('/')
    if urllib.parse.urlparse(domain).scheme != 'https':
        raise RuntimeError('Upload domain must use HTTPS.')
    headers = {'ous-token-v2': token['ousToken']}
    content = photo.read_bytes()
    size = int(token['blockSize'])
    if size <= 0:
        raise RuntimeError('Invalid upload block size.')
    digest = hashlib.md5(content).hexdigest()
    if len(content) > size:
        query = urllib.parse.urlencode(dict(md5=digest, blocks=(len(content)+size-1)//size, size=len(content), name='photo.jpg'))
        init = unwrap(request(domain + '/ous/api/v2/block/upload/init?' + query, headers, method='POST'))
        if not init.get('deduplicated'):
            for index, offset in enumerate(range(0, len(content), size), 1):
                post_part(domain, headers, '/ous/api/v2/block/upload/part', {'block': index}, content[offset:offset+size])
    else:
        post_part(domain, headers, '/ous/api/v2/single/upload', {'md5': digest}, content)
    for _ in range(150):
        status = unwrap(request(domain + '/ous/api/v2/upload/status', headers))
        if status['status'] == 5 and status.get('url'):
            return status['url']
        if status['status'] in (6, 8):
            raise RuntimeError('Photo upload failed.')
        time.sleep(2)
    raise TimeoutError('Photo upload timed out.')


def post_part(domain, headers, route, fields, chunk):
    body, boundary = multipart(fields, chunk)
    unwrap(request(domain + route, {**headers, 'Content-Type': 'multipart/form-data; boundary=' + boundary}, body))


def create_stage(name, payload, context):
    state, path, key = context
    if state.get(name + '_pending'):
        raise RuntimeError('Previous create response was not recorded. Check console before clearing pending state; do not resubmit blindly.')
    state[name + '_pending'] = True
    save(path, state)
    reply = request(BASE + '/lux3d/v1/generate/' + name + '/task/create',
                    {'Authorization': key, 'Content-Type': 'application/json'}, json.dumps(payload).encode())
    task_id = unwrap(reply)
    state[name] = task_id
    state.pop(name + '_pending')
    save(path, state)
    print(f'{name}: task {task_id}', flush=True)


def wait_for(task_id, key):
    for _ in range(240):
        detail = unwrap(request(BASE + '/lux3d/v1/generate/task/get?taskid=' + str(task_id), {'Authorization': key}))
        status = detail['status']
        print(f'Task {task_id}: status {status}', flush=True)
        if status == 3:
            return detail['outputs']
        if status in (4, 6):
            raise RuntimeError(f'Task {task_id} failed/canceled. No new generation submitted.')
        time.sleep(10)
    raise TimeoutError('Polling timed out. Restart to continue polling the same task.')


def download(url, target):
    if urllib.parse.urlparse(url).scheme != 'https':
        raise RuntimeError('Result must be an HTTPS URL.')
    with urllib.request.urlopen(url, timeout=120) as response:
        content = response.read()
    temporary = target.with_suffix('.part')
    temporary.write_bytes(content)
    temporary.replace(target)


def pipeline(args, key):
    folder = ROOT / 'runs' / args.run
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / 'state.json'
    state = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    photo = Path(args.photo).resolve()
    identity = {'sha256': hashlib.sha256(photo.read_bytes()).hexdigest(), 'prompt': (ROOT / 'prompt.txt').read_text(encoding='utf-8').strip()}
    if state.get('input', identity) != identity:
        raise RuntimeError('Photo/prompt changed: use a different --run name.')
    state['input'] = identity
    if state.get('completed') and (folder / 'model.glb').exists():
        print(f'Already completed: {folder / "model.glb"}')
        return
    if 'photo_url' not in state:
        state['photo_url'] = upload(photo, key)
        save(path, state)
    image_stage = 'multimodal-to-image'
    if image_stage not in state:
        create_stage(image_stage, {'img': state['photo_url'], 'prompt': identity['prompt']}, (state, path, key))
    image_outputs = wait_for(state[image_stage], key)
    if not (folder / 'wasteland.png').exists():
        download(image_outputs[0]['content'], folder / 'wasteland.png')
    if args.image_only:
        print('Image saved. Restart without --image-only to continue to 3D.')
        return
    model_stage = 'img-to-3d'
    if model_stage not in state:
        payload = dict(img=image_outputs[0]['content'], version='G1-Turbo', faceCount=100000, enablePbr=True, outputFormat=['zip', 'glb'], aiPredictSize=False)
        create_stage(model_stage, payload, (state, path, key))
    outputs = wait_for(state[model_stage], key)
    download(outputs[1]['content'], folder / 'model.glb')
    content = (folder / 'model.glb').read_bytes()
    if len(content) < 20 or struct.unpack_from('<4sII', content) != (b'glTF', 2, len(content)):
        raise RuntimeError('Downloaded file is not a valid GLB v2 container.')
    state['completed'] = True
    save(path, state)
    print(f'Completed: {folder / "model.glb"}', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--photo', required=True, help='Absolute path to a JPG/PNG photo')
    parser.add_argument('--run', default='pot-001')
    parser.add_argument('--image-only', action='store_true')
    args = parser.parse_args()
    if Path(args.run).name != args.run or args.run in ('.', '..'):
        parser.error('--run must be a simple folder name')
    completed_path = ROOT / 'runs' / args.run / 'state.json'
    if completed_path.exists() and (completed_path.parent / 'model.glb').exists():
        completed = json.loads(completed_path.read_text(encoding='utf-8'))
        identity = {'sha256': hashlib.sha256(Path(args.photo).read_bytes()).hexdigest(),
                    'prompt': (ROOT / 'prompt.txt').read_text(encoding='utf-8').strip()}
        if completed.get('completed') and completed.get('input') == identity:
            print(f'Already completed: {completed_path.parent / "model.glb"}')
            return
    key = os.environ.get('AHOLO_API_KEY') or getpass.getpass('Paste Aholo API key (hidden; memory only): ')
    if not key.strip():
        raise RuntimeError('API key is required.')
    pipeline(args, key.strip())


if __name__ == '__main__':
    main()
